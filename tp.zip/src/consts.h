#pragma once

#include <stdio.h>

#define BLOCK_SZ 20
#define TAPES_SZ 40
#define HALF_TAPES_SZ TAPES_SZ / 2
#define AREA_SZ 100