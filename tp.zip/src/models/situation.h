#pragma once

// Represents the file situation (ascending, descending or random)
typedef enum Situation { ASC = 1, DESC = 2, RANDOM = 3 } Situation;